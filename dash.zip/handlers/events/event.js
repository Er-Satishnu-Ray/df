module.exports = class {
  on = '';
  
  invoke(...args) {
    throw new TypeError('Invoke not implemented.');
  }
}